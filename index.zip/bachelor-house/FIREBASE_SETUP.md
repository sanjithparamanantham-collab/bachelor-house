# 🔥 Firebase Setup Guide — Bachelor House Manager

## Step 1: Create Firebase Project (FREE)
1. Go to https://console.firebase.google.com
2. Click **"Add project"** → Give it a name like `bachelor-house`
3. Disable Google Analytics (not needed) → **Create project**

## Step 2: Enable Firestore Database
1. In the left menu: **Build → Firestore Database**
2. Click **"Create database"**
3. Choose **"Start in test mode"** → Next
4. Select a region close to you (e.g. `asia-south1` for India) → **Enable**

## Step 3: Enable Anonymous Authentication
1. In the left menu: **Build → Authentication**
2. Click **"Get started"**
3. Click **"Anonymous"** provider → Toggle **Enable** → Save

## Step 4: Get Your Firebase Config
1. Click the **gear icon** (⚙️) → **Project settings**
2. Scroll down to **"Your apps"** → Click **"<\/>"** (web app icon)
3. Give it a nickname (e.g. `house-app`) → **Register app**
4. You'll see a `firebaseConfig` object — copy the values

## Step 5: Paste Config into the App
Open `js/firebase-config.js` and replace each placeholder:

```javascript
const FIREBASE_CONFIG = {
  apiKey:            "AIzaSy...",        // ← paste your real value
  authDomain:        "bachelor-house.firebaseapp.com",
  projectId:         "bachelor-house",
  storageBucket:     "bachelor-house.appspot.com",
  messagingSenderId: "123456789",
  appId:             "1:123456789:web:abc123"
};
```

## Step 6: Set Firestore Security Rules
In Firestore → **Rules** tab → Replace with:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Click **Publish**.

## Step 7: Deploy to GitHub Pages
1. Go to https://github.com → **New repository** → name it `bachelor-house`
2. Upload all the files (drag & drop works)
3. Go to repo **Settings → Pages**
4. Source: **Deploy from a branch** → Branch: **main** → **Save**
5. Wait ~2 minutes → site live at `https://YOUR_USERNAME.github.io/bachelor-house`

## Step 8: Share With Housemates
Send the URL to all 6 housemates. When they open it:
- They'll see "Join the House" and pick their name
- They click **Allow** when asked for notifications
- Done! Everything syncs in real-time ☁️

## Firestore Data Structure
```
/config/house_config     → house name, rent, members list
/water_entries/{id}      → each water can purchase + who paid
/rent/{YYYY-MM}          → monthly rent payment status
/activity/{id}           → activity feed
/notifications/{id}      → notification log  
/sweep_done/{YYYY-MM-DD} → days when sweep was marked done
```

## Cost
Everything above is **completely FREE**:
- Firebase Firestore free tier: 1 GB storage, 50,000 reads/day, 20,000 writes/day
- GitHub Pages: unlimited free hosting
- For 7 people in a house, you'll use < 1% of the free limits
