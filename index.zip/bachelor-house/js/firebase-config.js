// ============================================================
// FIREBASE CONFIGURATION — Replace with your project values
// ============================================================
// HOW TO GET THESE VALUES:
// 1. Go to https://console.firebase.google.com
// 2. Create a new project (free tier)
// 3. Project Settings → Your apps → Add web app (</>)
// 4. Copy the config object values below
// 5. Enable Firestore Database (Build → Firestore → Create database → Test mode)
// 6. Enable Authentication (Build → Authentication → Get started → Anonymous → Enable)
// ============================================================

const FIREBASE_CONFIG = {
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAdryu-2NPhRdxQfnvuGlu8dEBorVNjMMM",
  authDomain: "bachelor-house-593d6.firebaseapp.com",
  databaseURL: "https://bachelor-house-593d6-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "bachelor-house-593d6",
  storageBucket: "bachelor-house-593d6.firebasestorage.app",
  messagingSenderId: "706486529360",
  appId: "1:706486529360:web:39a3a783c1925f8b6b9055"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
};

// ── VAPID key for push notifications (optional but recommended) ──
// Firebase Console → Project Settings → Cloud Messaging → Web Push certificates → Generate key pair
const VAPID_KEY = "PASTE_YOUR_VAPID_KEY_HERE";

window.FIREBASE_CONFIG   = FIREBASE_CONFIG;
window.VAPID_KEY         = VAPID_KEY;
